"""Record operations for the navigator: list, detail, manual memories, edits.

Producer discipline: this app owns `tags`, `annotations`, top-level `summary`,
and the `human.*` / `akousmata.*` listening namespaces. It never reshapes
another producer's listening block — the same additive rule every app in the
Listening Stack follows.
"""
from __future__ import annotations

import io
import json
import sqlite3
import time
import wave
from hashlib import sha256
from pathlib import Path
from typing import Any

from akousmata_app import AKOUSMATA_CONTRACT
from akousmata_app.paths import ensure_pyakousma

EDITABLE_FIELDS = {"tags", "annotations", "summary", "location"}
AUDIO_EXTENSIONS = {"aif", "aiff", "flac", "m4a", "mp3", "ogg", "opus", "wav", "webm"}
MAX_MANUAL_AUDIO_BYTES = 100 * 1024 * 1024
RECORD_CLASSES = {"human", "agent", "hybrid", "plural_other", "decision_only", "legacy"}
MACHINE_LISTENER_TYPE = "agent"

# Meteorological convention, not an ecological claim (see /api/timeline docs).
_SEASON_BY_MONTH = {
    12: "DJF", 1: "DJF", 2: "DJF",
    3: "MAM", 4: "MAM", 5: "MAM",
    6: "JJA", 7: "JJA", 8: "JJA",
    9: "SON", 10: "SON", 11: "SON",
}


def _akousma():
    ensure_pyakousma()
    import akousma

    return akousma


def _utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def listener_types(record: dict[str, Any]) -> list[str]:
    """Exact listener types declared by the auditum, never namespace guesses."""
    lib = _akousma()
    if hasattr(lib, "listener_types"):
        return list(lib.listener_types(record))
    block = record.get("auditum")
    listenings = block.get("listenings") if isinstance(block, dict) else None
    if not isinstance(listenings, list):
        return []
    return sorted({
        str(item["listener_type"])
        for item in listenings
        if isinstance(item, dict)
        and isinstance(item.get("listener_type"), str)
        and item["listener_type"]
    })


def record_class(record: dict[str, Any]) -> str:
    """Classify a record while retaining every exact listener type.

    ``hybrid`` is reserved for an explicit hybrid listener or a human+agent
    account. Community, institution, sensor, habitat, animal, ensemble, and
    other listenings stay visible in ``listener_types`` and use the
    ``plural_other`` navigation bucket rather than being called machines.
    """
    lib = _akousma()
    if hasattr(lib, "record_class"):
        return str(lib.record_class(record))
    block = record.get("auditum")
    if not isinstance(block, dict):
        return "legacy"
    types = set(listener_types(record))
    decisions = block.get("route_decisions")
    if not types and isinstance(decisions, list) and decisions:
        return "decision_only"
    if types == {"human"}:
        return "human"
    if types == {MACHINE_LISTENER_TYPE}:
        return "agent"
    if types == {"hybrid"} or types == {"human", MACHINE_LISTENER_TYPE}:
        return "hybrid"
    if types:
        return "plural_other"
    return "legacy"


def _human_record_meta(record: dict[str, Any]) -> dict[str, Any]:
    extensions = record.get("extensions")
    app = extensions.get("akousmata.app") if isinstance(extensions, dict) else None
    meta = app.get("human_record") if isinstance(app, dict) else None
    return meta if isinstance(meta, dict) else {}


def owned_human_record(record: dict[str, Any], listener_id: str | None) -> bool:
    meta = _human_record_meta(record)
    return bool(listener_id and meta.get("owner_listener_id") == listener_id)


def _revision_index(store) -> dict[str, Any]:
    parent: dict[str, str] = {}
    children: dict[str, list[str]] = {}
    try:
        rows = store.conn.execute("SELECT akousma_id, revision_of FROM akousmata").fetchall()
        pairs = [(row["akousma_id"], row["revision_of"]) for row in rows]
    except sqlite3.OperationalError:  # py-akousma < 0.7 compatibility while a store migrates
        rows = store.conn.execute("SELECT akousma_id, record FROM akousmata").fetchall()
        pairs = []
        for row in rows:
            record = json.loads(row["record"])
            revision = (record.get("auditum") or {}).get("revision")
            target = revision.get("revises_akousma_id") if isinstance(revision, dict) else None
            pairs.append((row["akousma_id"], target))
    for rid, target in pairs:
        if isinstance(target, str) and target:
            parent[rid] = target
            children.setdefault(target, []).append(rid)
    return {"parent": parent, "children": children}


def _lifecycle_from_index(index: dict[str, Any], akousma_id: str) -> dict[str, Any]:
    parent = index["parent"]
    children = index["children"]
    root = akousma_id
    seen: set[str] = set()
    while root in parent and root not in seen:
        seen.add(root)
        root = parent[root]

    member_ids: set[str] = set()
    stack = [root]
    while stack:
        current = stack.pop()
        if current in member_ids:
            continue
        member_ids.add(current)
        stack.extend(children.get(current, []))
    heads = sorted(rid for rid in member_ids if not children.get(rid))
    return {
        "root_id": root,
        "revision_of": parent.get(akousma_id),
        "member_ids": member_ids,
        "head_ids": heads,
        "is_head": akousma_id in heads,
    }


def revision_lifecycle(store, akousma_id: str) -> dict[str, Any]:
    state = _lifecycle_from_index(_revision_index(store), akousma_id)
    history = [store.get(rid) for rid in state.pop("member_ids")]
    state["history"] = sorted(
        (record for record in history if record is not None),
        key=lambda item: (str(item.get("created_at") or ""), item["akousma_id"]),
    )
    return state


def cards(store, found: list[dict[str, Any]], *, local_listener_id: str | None = None) -> list[dict[str, Any]]:
    index = _revision_index(store)
    return [
        card(
            record,
            lifecycle=_lifecycle_from_index(index, record["akousma_id"]),
            local_listener_id=local_listener_id,
        )
        for record in found
    ]


def list_records(
    store,
    *,
    app: str | None = None,
    origin: str | None = None,
    source_type: str | None = None,
    tag: str | None = None,
    text: str | None = None,
    since: str | None = None,
    until: str | None = None,
    covenant_id: str | None = None,
    has_auditum: bool | None = None,
    has_disagreement: bool | None = None,
    has_route_decision: bool | None = None,
    has_stop_decision: bool | None = None,
    listener_type: str | None = None,
    record_class_filter: str | None = None,
    revision_of: str | None = None,
    limit: int = 200,
    facets: dict[str, str] | None = None,
    offset: int = 0,
    oldest_first: bool = False,
) -> list[dict[str, Any]]:
    kwargs: dict[str, Any] = {}
    if offset or oldest_first:
        kwargs.update(offset=offset, oldest_first=oldest_first)
    if covenant_id is not None:
        # py-akousma >= 0.4; older stores simply have no covenant column
        kwargs["covenant_id"] = covenant_id
    if has_auditum is not None:
        kwargs["has_auditum"] = has_auditum
    if has_disagreement is not None:
        kwargs["has_disagreement"] = has_disagreement
    if has_route_decision is not None:
        kwargs["has_route_decision"] = has_route_decision
    if has_stop_decision is not None:
        kwargs["has_stop_decision"] = has_stop_decision
    if record_class_filter is not None and record_class_filter not in RECORD_CLASSES:
        raise ValueError(f"record_class must be one of {sorted(RECORD_CLASSES)}")
    if listener_type is not None:
        kwargs["listener_type"] = listener_type
    if record_class_filter is not None:
        kwargs["record_class"] = record_class_filter
    if revision_of is not None:
        kwargs["revision_of"] = revision_of
    if facets:
        if offset or oldest_first:
            raise ValueError("Access-facet queries do not support pagination or date sorting")
        from akousmata_app.access_view import find
        if listener_type is not None and listener_type not in _akousma().AUDITUM_LISTENER_TYPES:
            raise ValueError("Unknown listener type")
        return find(store, facets, locals(), limit)
    found = store.query(
        originating_app=app,
        origin=origin,
        source_type=source_type,
        tag=tag,
        text=text,
        since=since,
        until=until,
        limit=limit,
        **kwargs,
    )
    return found


def summary_line(record: dict[str, Any]) -> str:
    summary = record.get("summary")
    if isinstance(summary, str) and summary.strip():
        return summary.strip()
    listening = record.get("listening") or {}
    for entry in listening.values():
        if isinstance(entry, dict):
            text = entry.get("summary")
            if isinstance(text, str) and text.strip():
                return text.strip()
            payload = entry.get("payload") if isinstance(entry.get("payload"), dict) else entry
            for key in ("caption", "summary", "brief", "main_reading", "notes"):
                value = payload.get(key) if isinstance(payload, dict) else None
                if isinstance(value, str) and value.strip():
                    return value.strip()
    prompt = (record.get("lineage") or {}).get("prompt")
    if isinstance(prompt, str) and prompt.strip():
        return prompt.strip()
    subject = record.get("subject")
    if isinstance(subject, str) and subject.strip():
        return f"Decision about {subject.strip()}"
    return ", ".join(str(t) for t in record.get("tags") or []) or "(no summary)"


def card(
    record: dict[str, Any],
    *,
    lifecycle: dict[str, Any] | None = None,
    local_listener_id: str | None = None,
) -> dict[str, Any]:
    """Compact list representation."""
    provenance = record.get("provenance") or {}
    audio = record.get("audio") or {}
    lineage = record.get("lineage") or {}
    accountability = auditum_summary(record)
    lifecycle = lifecycle or {
        "root_id": None,
        "revision_of": accountability["revision_of"],
        "head_ids": [],
        "is_head": None,
    }
    owned = owned_human_record(record, local_listener_id)
    exact_listener_types = listener_types(record)
    classification = record_class(record)
    return {
        "akousma_id": record["akousma_id"],
        "created_at": record.get("created_at"),
        "summary": summary_line(record),
        "tags": list(record.get("tags") or []),
        "originating_app": provenance.get("originating_app"),
        "origin": provenance.get("origin"),
        "source_type": provenance.get("source_type"),
        "duration_seconds": audio.get("duration_seconds"),
        "has_audio": bool(audio.get("uri")),
        "has_location": isinstance((record.get("location") or {}).get("lat"), (int, float)),
        "covenant_id": (record.get("covenant") or {}).get("id"),
        "auditum_contract": accountability["contract"],
        "listening_count": accountability["listening_count"],
        "distinct_listener_count": accountability["distinct_listener_count"],
        "disagreement_count": accountability["disagreement_count"],
        "honest_absence_count": accountability["honest_absence_count"],
        "action_count": accountability["action_count"],
        "route_decision_count": accountability["route_decision_count"],
        "stop_decision_count": accountability["stop_decision_count"],
        "decision_only": accountability["decision_only"],
        "ensemble_kind": accountability["ensemble_kind"],
        "revision_of": lifecycle.get("revision_of") or accountability["revision_of"],
        "revision_root": lifecycle.get("root_id"),
        "revision_head_ids": list(lifecycle.get("head_ids") or []),
        "is_revision_head": lifecycle.get("is_head"),
        "record_class": classification,
        "listener_types": exact_listener_types,
        "owned_human_record": owned,
        "human_editable": owned and bool(lifecycle.get("is_head")) and len(lifecycle.get("head_ids") or []) == 1,
        "parent_count": len(lineage.get("parent_akousma_ids") or []),
        "relation_count": len(lineage.get("relations") or []),
        # Compatibility alias; values now come from accountable listener_type,
        # never from producer namespace spelling.
        "listener_kinds": exact_listener_types,
    }


def detail(store, akousma_id: str, *, local_listener_id: str | None = None) -> dict[str, Any] | None:
    record = store.get(akousma_id)
    if record is None:
        return None
    parents = [pid for pid in store.parents(akousma_id)]
    children = [cid for cid in store.children(akousma_id)]
    related = store.related(akousma_id) if hasattr(store, "related") else []
    audio_path = resolve_audio_path(store, record)
    lifecycle = revision_lifecycle(store, akousma_id)
    owned = owned_human_record(record, local_listener_id)
    from akousmata_app.listening_relations import project
    from akousmata_app.access_view import project as access_project
    return {
        "access_view": access_project(record),
        "listening_relations": project(record, store.get),
        "record": record,
        "card": card(record, lifecycle=lifecycle, local_listener_id=local_listener_id),
        "summary": summary_line(record),
        "accountability": auditum_summary(record),
        "parents": [_ref(store, pid) for pid in parents],
        "children": [_ref(store, cid) for cid in children],
        "related": [
            {**link, "summary": _ref_summary(store, link.get("akousma_id"))}
            for link in related
        ],
        "audio_available": audio_path is not None,
        "human_record": {
            "owned_locally": owned,
            "editable": owned and lifecycle["is_head"] and len(lifecycle["head_ids"]) == 1,
            "owner_listener_id": _human_record_meta(record).get("owner_listener_id"),
        },
        "revision": {
            "root_id": lifecycle["root_id"],
            "head_ids": lifecycle["head_ids"],
            "is_head": lifecycle["is_head"],
            "history": [
                {
                    "akousma_id": item["akousma_id"],
                    "created_at": item.get("created_at"),
                    "summary": summary_line(item),
                    "record_class": record_class(item),
                    "listener_types": listener_types(item),
                    "owned_human_record": owned_human_record(item, local_listener_id),
                }
                for item in lifecycle["history"]
            ],
        },
    }


def auditum_summary(record: dict[str, Any], *, known_record_ids: set[str] | None = None) -> dict[str, Any]:
    """Inspect v1/v2 accountability without adjudicating any listening claim.

    A v2 auditum may be a hearing or a complete decision made before hearing.
    Plural listeners are not called an ear swarm unless an explicit ensemble
    declares influence, preserved permissions/disagreement, and dissolution.
    """
    empty = {
        "status": "legacy",
        "contract": None,
        "listening_count": 0,
        "distinct_listener_count": 0,
        "plural_listening": False,
        "ensemble_kind": None,
        "ear_swarm": False,
        "disagreement_count": 0,
        "honest_absence_count": 0,
        "action_count": 0,
        "route_decision_count": 0,
        "stop_decision_count": 0,
        "decision_only": False,
        "revision_of": None,
        "issues": [],
    }
    block = record.get("auditum")
    if not isinstance(block, dict):
        return empty

    issues: list[str] = []
    contract = block.get("contract")
    if contract not in {"earworm/auditum/v1", "earworm/auditum/v2"}:
        issues.append("auditum contract is missing or unsupported")

    listenings = block.get("listenings") if isinstance(block.get("listenings"), list) else []
    listening_ids: list[str] = []
    listener_ids: set[str] = set()
    namespaces = record.get("listening") if isinstance(record.get("listening"), dict) else {}
    for index, item in enumerate(listenings):
        if not isinstance(item, dict):
            issues.append(f"listening {index + 1} is not an object")
            continue
        listening_id = item.get("listening_id")
        if not isinstance(listening_id, str) or not listening_id:
            issues.append(f"listening {index + 1} has no id")
        else:
            listening_ids.append(listening_id)
        listener_id = item.get("listener_id")
        if isinstance(listener_id, str) and listener_id:
            listener_ids.add(listener_id)
        else:
            issues.append(f"listening {listening_id or index + 1} has no listener attribution")
        namespace = item.get("report_namespace")
        if not isinstance(namespace, str) or namespace not in namespaces:
            issues.append(f"listening {listening_id or index + 1} points to a missing report namespace")
        for influence in item.get("influenced_by") or []:
            if not isinstance(influence, dict) or not influence.get("listening_id") or not influence.get("effect"):
                issues.append(f"listening {listening_id or index + 1} has an incomplete influence declaration")
    if len(set(listening_ids)) != len(listening_ids):
        issues.append("listening ids are not unique")
    listening_id_set = set(listening_ids)
    for item in listenings:
        if not isinstance(item, dict):
            continue
        for influence in item.get("influenced_by") or []:
            if isinstance(influence, dict) and influence.get("listening_id") not in listening_id_set:
                issues.append(f"listening {item.get('listening_id') or '?'} is influenced by an unknown listening")

    decisions = block.get("route_decisions") if isinstance(block.get("route_decisions"), list) else []
    decision_ids: list[str] = []
    stop_outcomes = {"pause", "defer", "abstain", "refuse", "withhold", "forget", "do_not_act"}
    stop_decisions = []
    for index, decision in enumerate(decisions):
        if not isinstance(decision, dict):
            issues.append(f"route decision {index + 1} is not an object")
            continue
        decision_id = decision.get("decision_id")
        if not isinstance(decision_id, str) or not decision_id:
            issues.append(f"route decision {index + 1} has no id")
        else:
            decision_ids.append(decision_id)
        authority = decision.get("authority") if isinstance(decision.get("authority"), dict) else {}
        if not authority.get("actor"):
            issues.append(f"route decision {decision_id or index + 1} has no attributed actor")
        linked_listening = decision.get("listening_id")
        if linked_listening is not None and linked_listening not in listening_id_set:
            issues.append(f"route decision {decision_id or index + 1} references an unknown listening")
        if decision.get("outcome") in stop_outcomes:
            stop_decisions.append(decision)
    if len(set(decision_ids)) != len(decision_ids):
        issues.append("route decision ids are not unique")

    has_precapture_stop = any(
        decision.get("gate") in {"input", "capture"}
        and decision.get("outcome") in {"pause", "defer", "abstain", "refuse", "withhold"}
        for decision in decisions
        if isinstance(decision, dict)
    )
    decision_only = not listenings and has_precapture_stop
    if contract == "earworm/auditum/v1" and not listenings:
        issues.append("auditum/v1 has no attributable listenings")
    if contract == "earworm/auditum/v2" and not decisions:
        issues.append("auditum/v2 has no route decisions")
    if not listenings and decisions and not has_precapture_stop:
        issues.append("an empty listening list needs an input or capture stop decision")

    disagreements = block.get("disagreements") if isinstance(block.get("disagreements"), list) else []
    for index, disagreement in enumerate(disagreements):
        if not isinstance(disagreement, dict):
            issues.append(f"disagreement {index + 1} is not an object")
            continue
        participants = disagreement.get("listening_ids") if isinstance(disagreement.get("listening_ids"), list) else []
        if len(set(participants)) < 2:
            issues.append(f"disagreement {disagreement.get('id') or index + 1} has fewer than two listenings")
        if not set(participants).issubset(listening_id_set):
            issues.append(f"disagreement {disagreement.get('id') or index + 1} references an unknown listening")
        positions = disagreement.get("positions") if isinstance(disagreement.get("positions"), list) else []
        position_ids = {
            position.get("listening_id")
            for position in positions
            if isinstance(position, dict) and isinstance(position.get("listening_id"), str)
        }
        if not set(participants).issubset(position_ids):
            issues.append(f"disagreement {disagreement.get('id') or index + 1} omits a participant position")
        if disagreement.get("status") == "resolved" and not disagreement.get("resolution_note"):
            issues.append(f"resolved disagreement {disagreement.get('id') or index + 1} has no attributable note")

    absences = block.get("honest_absences") if isinstance(block.get("honest_absences"), list) else []
    for index, absence in enumerate(absences):
        if not isinstance(absence, dict) or not absence.get("attributed_to"):
            issues.append(f"honest absence {index + 1} is unattributed")
        elif contract == "earworm/auditum/v2" and absence.get("kind") == "undetermined":
            issues.append(f"honest absence {index + 1} uses undetermined, which belongs to claims")

    actions = block.get("actions") if isinstance(block.get("actions"), list) else []
    for index, action in enumerate(actions):
        if not isinstance(action, dict):
            issues.append(f"action {index + 1} is not an object")
            continue
        authority = action.get("authority") if isinstance(action.get("authority"), dict) else {}
        status = action.get("status")
        if status in {"authorized", "executed"} and authority.get("mode") != "execute_scoped":
            issues.append(f"action {action.get('action_id') or index + 1} exceeds its declared authority")
        if status in {"executed", "failed", "reverted"} and not isinstance(action.get("receipt"), dict):
            issues.append(f"action {action.get('action_id') or index + 1} has no receipt")

    ensemble = block.get("ensemble") if isinstance(block.get("ensemble"), dict) else None
    ensemble_kind = ensemble.get("kind") if ensemble else None
    if ensemble:
        ensemble_ids = ensemble.get("listening_ids") if isinstance(ensemble.get("listening_ids"), list) else []
        if len(set(ensemble_ids)) < 2 or not set(ensemble_ids).issubset(listening_id_set):
            issues.append("ensemble does not identify at least two known listenings")
        if ensemble_kind == "ear_swarm":
            if not ensemble.get("influence_edges"):
                issues.append("ear swarm has no influence edges")
            if ensemble.get("permissions_preserved") is not True:
                issues.append("ear swarm does not preserve permissions")
            if ensemble.get("disagreements_preserved") is not True:
                issues.append("ear swarm does not preserve disagreements")
            if not ensemble.get("dissolution_rule"):
                issues.append("ear swarm has no dissolution rule")

    revision = block.get("revision") if isinstance(block.get("revision"), dict) else None
    revision_of = revision.get("revises_akousma_id") if revision else None
    if revision_of and known_record_ids is not None and revision_of not in known_record_ids:
        issues.append("revision target is missing")

    return {
        "status": "issues" if issues else "accountable",
        "contract": contract if isinstance(contract, str) else None,
        "listening_count": len(listenings),
        "distinct_listener_count": len(listener_ids),
        "plural_listening": len(listener_ids) > 1,
        "ensemble_kind": ensemble_kind,
        "ear_swarm": ensemble_kind == "ear_swarm",
        "disagreement_count": len(disagreements),
        "honest_absence_count": len(absences),
        "action_count": len(actions),
        "route_decision_count": len(decisions),
        "stop_decision_count": len(stop_decisions),
        "decision_only": decision_only,
        "revision_of": revision_of,
        "issues": issues,
    }


def _ref(store, akousma_id: str) -> dict[str, Any]:
    record = store.get(akousma_id)
    if record is None:
        return {"akousma_id": akousma_id, "summary": "(missing record — absence is information)", "missing": True}
    return {"akousma_id": akousma_id, "summary": summary_line(record), "missing": False}


def _ref_summary(store, akousma_id: str | None) -> str:
    if not akousma_id:
        return ""
    record = store.get(akousma_id)
    return summary_line(record) if record else "(missing record)"


def resolve_audio_path(store, record: dict[str, Any]) -> Path | None:
    if 'oida.spectral' in record.get('extensions', {}):
        from akousmata_app.derivatives import authorized_bundle
        try:
            authorized_bundle(store, record['akousma_id'])
        except ValueError:
            return None
    uri = str((record.get("audio") or {}).get("uri") or "")
    if uri.startswith("akousmata://"):
        path = store.resolve_uri(uri, content_hash=(record.get("audio") or {}).get("content_hash"))
        return path if path is not None and path.exists() else None
    if uri.startswith("file://"):
        path = Path(uri[7:])
        return path if path.exists() else None
    if uri and Path(uri).expanduser().exists():
        return Path(uri).expanduser()
    return None


def _wav_bytes_duration(data: bytes) -> float | None:
    try:
        with wave.open(io.BytesIO(data), "rb") as handle:
            frames = handle.getnframes()
            rate = handle.getframerate()
            return round(frames / float(rate), 3) if rate else None
    except (EOFError, wave.Error):
        return None


def normalize_audio_extension(value: str) -> str:
    extension = value.lower().lstrip(".")
    if extension not in AUDIO_EXTENSIONS:
        raise ValueError("unsupported audio file type")
    return extension


def _checked_location(value: dict[str, Any]) -> dict[str, Any]:
    """Validate a location dict through the spec builder (v1.2 ranges/enums)."""
    lib = _akousma()
    label = value.get("label")
    try:
        return lib.location(
            value.get("lat"),
            value.get("lon"),
            accuracy_m=value.get("accuracy_m"),
            altitude_m=value.get("altitude_m"),
            label=str(label).strip() or None if label is not None else None,
            source=value.get("source") or "manual",
            captured_at=value.get("captured_at"),
        )
    except (TypeError, ValueError) as exc:
        raise ValueError(f"invalid location: {exc}") from exc


def create_manual_memory(
    store,
    *,
    summary: str,
    notes: str = "",
    tags: list[str] | None = None,
    heard_at: str | None = None,
    place: str | None = None,
    kind: str = "heard_live",
    audio_data: bytes | None = None,
    audio_extension: str = "wav",
    parent_akousma_ids: list[str] | None = None,
    relations: list[dict[str, Any]] | None = None,
    location: dict[str, Any] | None = None,
    heard: bool = True,
    human_profile: dict[str, str] | None = None,
    revision_of: str | None = None,
    revision_reason: str | None = None,
    revision_changes: list[str] | None = None,
    retained_audio: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create an additive, locally owned human account.

    ``heard`` is explicit evidence. A human account always carries an
    attributable listening entry, but notes never manufacture a ``heard``
    claim: when ``heard`` is false the payload and honest absence preserve that
    distinction explicitly.
    """
    lib = _akousma()
    if human_profile is None:
        from akousmata_app.settings import ensure_human_profile

        human_profile = ensure_human_profile()
    listener_id = str(human_profile.get("listener_id") or "").strip()
    if not listener_id:
        raise ValueError("a stable local human listener id is required")

    audio: dict[str, Any] | None = dict(retained_audio) if retained_audio else None
    origin = "unknown"
    source_type = "unknown"
    if audio:
        origin = "file"
        source_type = "imported"
    if audio_data is not None:
        if not audio_data:
            raise ValueError("uploaded audio is empty")
        if len(audio_data) > MAX_MANUAL_AUDIO_BYTES:
            raise ValueError("uploaded audio is larger than 100 MB")
        data = audio_data
        ext = normalize_audio_extension(audio_extension)
        audio = {"asset_id": f"manual_{lib.new_id('man')[4:]}"}
        audio["uri"] = store.put_audio(data, ext=ext)
        audio["content_hash"] = "sha256:" + sha256(data).hexdigest()
        duration = _wav_bytes_duration(data) if ext == "wav" else None
        if duration:
            audio["duration_seconds"] = duration
        origin = "file"
        source_type = "imported"

    payload: dict[str, Any] = {
        "notes": notes or summary,
        "hearing_evidence": {
            "kind": "self_attested_hearing" if heard else "hearing_not_attested",
            "confirmed": heard,
        },
    }
    if place:
        payload["place"] = place
    if heard_at:
        payload["heard_at"] = heard_at
    payload["kind"] = kind

    checked_location = _checked_location(location) if location else None
    if checked_location is not None and not checked_location.get("label") and place:
        checked_location["label"] = place

    created_at = _utc_now()
    # Namespace remains stable for older clients; classification comes only
    # from the auditum's listener_type, never from this spelling.
    namespace = "human.note"
    listening_id = lib.new_id("lst")
    decision_id = lib.new_id("dec")
    listening_entry = {
        "contract": AKOUSMATA_CONTRACT,
        "created_at": created_at,
        "summary": summary,
        "payload": payload,
    }
    honest_absences = []
    if audio is None:
        honest_absences.append({
            "id": lib.new_id("abs"),
            "kind": "not_retained",
            "subject": "raw audio",
            "attributed_to": listener_id,
            "listening_id": listening_id,
            "count": 1,
        })
    elif not heard:
        honest_absences.append({
            "id": lib.new_id("abs"),
            "kind": "refused",
            "subject": "human hearing claim",
            "attributed_to": listener_id,
            "listening_id": None,
            "count": 1,
            "note": "The author added a note without attesting that they heard the event.",
        })
    listening_items = [{
        "listening_id": listening_id,
        "listener_id": listener_id,
        "listener_type": "human",
        "created_at": created_at,
        "report_namespace": namespace,
        "contract": AKOUSMATA_CONTRACT,
        "claim_set_ref": None,
        "route": [
            "explicit-human-self-attestation"
            if heard
            else "explicit-human-account-without-hearing-claim"
        ],
        "route_decision_refs": [decision_id],
    }]
    route_decision = lib.route_decision(
        decision_id,
        gate="input",
        outcome="proceed",
        subject="human listening account" if heard else "human note without a hearing claim",
        reason=(
            "The local human explicitly attested to this bounded listening account."
            if heard
            else "The local human explicitly declined to turn this note into evidence of hearing."
        ),
        actor=listener_id,
        decided_at=created_at,
        listening_id=listening_id,
        producer_contract=AKOUSMATA_CONTRACT,
        authority_mode="execute_scoped",
        granted_by="explicit Add my listening action" if heard else "explicit note-without-hearing action",
        requires_confirmation=False,
        reversible=True,
    )
    revision = None
    if revision_of:
        revision = {
            "revision_id": lib.new_id("rev"),
            "revises_akousma_id": revision_of,
            "reason": (revision_reason or "the local human revised their listening account").strip(),
            "changes": list(revision_changes or ["human listening account revised"]),
            "created_at": created_at,
        }
    record = lib.new_akousma(
        audio=audio,
        subject=f"human account: {summary}" if audio is None else None,
        originating_app="akousmata",
        source_type=source_type,
        origin=origin,
        listening={namespace: listening_entry},
        parent_akousma_ids=parent_akousma_ids,
        relations=relations,
        tags=tags,
        summary=summary,
        location=checked_location,
        auditum=lib.auditum(
            listenings=listening_items,
            honest_absences=honest_absences,
            route_decisions=[route_decision],
            revision=revision,
        ),
    )
    root_id = revision_lifecycle(store, revision_of)["root_id"] if revision_of else record["akousma_id"]
    profile_display = str(human_profile.get("display_name") or "").strip()
    profile_privacy = str(human_profile.get("privacy") or "private")
    human_meta: dict[str, Any] = {
        "owner_listener_id": listener_id,
        "privacy": profile_privacy,
        "revision_root": root_id,
    }
    if profile_privacy == "shared" and profile_display:
        human_meta["display_name"] = profile_display
    record["extensions"]["akousmata.app"] = {
        "listener": {"type": "human", "process": "manual_entry"},
        "human_record": human_meta,
    }
    store.put(record)
    return record


def revise_human_record(
    store,
    akousma_id: str,
    *,
    human_profile: dict[str, str],
    summary: str,
    notes: str,
    tags: list[str] | None,
    heard_at: str | None,
    place: str | None,
    kind: str,
    location: dict[str, Any] | None,
    heard: bool,
    reason: str,
) -> dict[str, Any]:
    current = store.get(akousma_id)
    if current is None:
        raise KeyError(f"akousma not found: {akousma_id}")
    listener_id = str(human_profile.get("listener_id") or "")
    if not owned_human_record(current, listener_id):
        raise PermissionError("only a locally owned human record can be revised")
    lifecycle = revision_lifecycle(store, akousma_id)
    if len(lifecycle["head_ids"]) != 1:
        raise ValueError("the revision history has multiple heads; resolve the divergence before editing")
    if not lifecycle["is_head"]:
        raise ValueError("only the current revision head can be revised")
    if not reason.strip():
        raise ValueError("a revision reason is required")

    existing_relations = [
        dict(item)
        for item in ((current.get("lineage") or {}).get("relations") or [])
        if isinstance(item, dict) and item.get("type") != "replaces"
    ]
    existing_relations.append(_akousma().relation(
        "replaces",
        akousma_id,
        note="additive revision of a locally owned human listening account",
    ))
    changes = []
    previous_payload = next(
        (
            entry.get("payload") if isinstance(entry.get("payload"), dict) else entry
            for entry in (current.get("listening") or {}).values()
            if isinstance(entry, dict)
        ),
        {},
    )
    comparisons = {
        "summary": (summary_line(current), summary),
        "notes": (previous_payload.get("notes"), notes),
        "tags": (list(current.get("tags") or []), list(tags or [])),
        "heard_at": (previous_payload.get("heard_at"), heard_at),
        "place": (previous_payload.get("place"), place),
        "kind": (previous_payload.get("kind"), kind),
        "location": (current.get("location"), location),
        "hearing evidence": (record_class(current) == "human", heard),
    }
    for label, (before, after) in comparisons.items():
        if before != after:
            changes.append(label)
    if not changes:
        raise ValueError("the revision does not change the human account")

    revised = create_manual_memory(
        store,
        summary=summary,
        notes=notes,
        tags=tags,
        heard_at=heard_at,
        place=place,
        kind=kind,
        relations=existing_relations,
        location=location,
        heard=heard,
        human_profile=human_profile,
        revision_of=akousma_id,
        revision_reason=reason,
        revision_changes=changes,
        retained_audio=current.get("audio") if isinstance(current.get("audio"), dict) else None,
    )
    source_provenance = current.get("provenance") if isinstance(current.get("provenance"), dict) else {}
    provenance_patch = {
        key: source_provenance[key]
        for key in ("consent_status", "rights_note")
        if source_provenance.get(key) is not None
    }
    if provenance_patch:
        revised["provenance"].update(provenance_patch)
        store.put(revised)
    return revised


def update_record(store, akousma_id: str, patch: dict[str, Any]) -> dict[str, Any]:
    """Curate app-owned metadata only (tags, annotations, summary, location).

    This is deliberately separate from revising a human listening account.
    Machine listening/event/core fields remain protected by Earworm. Location
    is listener-annotatable per spec v1.2; ``{}`` clears it.
    """
    unknown = set(patch) - EDITABLE_FIELDS
    if unknown:
        raise ValueError(f"not editable: {', '.join(sorted(unknown))}. Editable: {', '.join(sorted(EDITABLE_FIELDS))}")
    record = store.get(akousma_id)
    if record is None:
        raise KeyError(f"akousma not found: {akousma_id}")
    if "tags" in patch:
        record["tags"] = [str(t) for t in (patch["tags"] or []) if str(t).strip()]
    if "summary" in patch:
        summary = str(patch["summary"] or "").strip()
        if summary:
            record["summary"] = summary
        else:
            record.pop("summary", None)
    if "annotations" in patch and isinstance(patch["annotations"], dict):
        record.setdefault("annotations", {}).update(patch["annotations"])
    if "location" in patch:
        value = patch["location"]
        if not isinstance(value, dict):
            raise ValueError("location must be an object with lat/lon, or {} to clear it")
        if not value:
            record.pop("location", None)
        else:
            record["location"] = _checked_location(value)
    app_extension = record.setdefault("extensions", {}).setdefault("akousmata.app", {})
    app_extension["edited_at"] = _utc_now()  # compatibility with <=0.6 clients
    app_extension["curation_edited_at"] = app_extension["edited_at"]
    store.put(record)
    return record


def add_relation(
    store,
    akousma_id: str,
    rel_type: str,
    target_akousma_id: str,
    note: str | None = None,
    *,
    local_listener_id: str | None = None,
    same_source_verified: bool = False,
) -> dict[str, Any]:
    lib = _akousma()
    record = store.get(akousma_id)
    if record is None:
        raise KeyError(f"akousma not found: {akousma_id}")
    target = store.get(target_akousma_id)
    if target is None:
        raise KeyError(f"akousma not found: {target_akousma_id}")
    if rel_type in {"response_to", "same_source_as"}:
        if not owned_human_record(record, local_listener_id):
            raise PermissionError(f"{rel_type} links must originate from a locally owned human record")
        if record_class(target) not in {"agent", "hybrid"}:
            raise ValueError(f"{rel_type} target must contain an attributable agent or hybrid listening")
    if rel_type == "same_source_as" and not same_source_verified:
        raise ValueError("same_source_as requires explicit source verification")
    relations = record.setdefault("lineage", {}).setdefault("relations", [])
    if not any(r.get("type") == rel_type and r.get("target_akousma_id") == target_akousma_id for r in relations):
        relations.append(lib.relation(rel_type, target_akousma_id, note))
        store.put(record)
    return record


def remove_relation(store, akousma_id: str, rel_type: str, target_akousma_id: str) -> dict[str, Any]:
    record = store.get(akousma_id)
    if record is None:
        raise KeyError(f"akousma not found: {akousma_id}")
    relations = record.get("lineage", {}).get("relations") or []
    kept = [r for r in relations if not (r.get("type") == rel_type and r.get("target_akousma_id") == target_akousma_id)]
    if len(kept) != len(relations):
        if kept:
            record["lineage"]["relations"] = kept
        else:
            record["lineage"].pop("relations", None)
        store.put(record)
    return record


def timeline(store, *, bucket: str = "day") -> dict[str, Any]:
    """Memories over time: counts per bucket with apps and top tags — the
    library's rhythm made visible."""
    from datetime import datetime
    import json as _json

    sizes = {"day": 10, "month": 7, "year": 4}
    if bucket not in {*sizes, "season"}:
        raise ValueError("bucket must be day, month, season, or year")
    size = sizes.get(bucket)
    rows = store.conn.execute("SELECT record FROM akousmata ORDER BY created_at ASC").fetchall()
    buckets: dict[str, dict[str, Any]] = {}
    weekdays: dict[str, int] = {}
    hours: dict[str, int] = {}
    for row in rows:
        record = _json.loads(row["record"])
        timestamp = str(record.get("created_at") or "")
        try:
            moment = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
        except ValueError:
            moment = None
        if bucket == "season" and moment is not None:
            season = _SEASON_BY_MONTH[moment.month]
            season_year = moment.year + 1 if moment.month == 12 else moment.year
            created = f"{season_year}-{season}"
        else:
            created = timestamp[:size] if size else ""
        if not created:
            continue
        if moment is not None:
            weekday = moment.strftime("%A").lower()
            hour = f"{moment.hour:02d}"
            weekdays[weekday] = weekdays.get(weekday, 0) + 1
            hours[hour] = hours.get(hour, 0) + 1
        entry = buckets.setdefault(created, {"bucket": created, "count": 0, "by_app": {}, "tag_counts": {}})
        entry["count"] += 1
        app = (record.get("provenance") or {}).get("originating_app") or "unknown"
        entry["by_app"][app] = entry["by_app"].get(app, 0) + 1
        for tag in record.get("tags") or []:
            entry["tag_counts"][tag] = entry["tag_counts"].get(tag, 0) + 1
    out = []
    for entry in buckets.values():
        tags = sorted(entry.pop("tag_counts").items(), key=lambda item: -item[1])[:4]
        entry["top_tags"] = [tag for tag, _ in tags]
        out.append(entry)
    return {
        "bucket": bucket,
        "buckets": out,
        "total": sum(entry["count"] for entry in out),
        "recurrence_rhythms": {
            "by_weekday": weekdays,
            "by_hour_utc": hours,
            "peak_weekday": max(weekdays, key=weekdays.get) if weekdays else None,
            "peak_hour_utc": max(hours, key=hours.get) if hours else None,
            "note": "Season labels are calendar groupings (DJF/MAM/JJA/SON), not ecological-season claims.",
        },
    }


def map_points(store) -> dict[str, Any]:
    """The listening map's feed: every located memory as a light point."""
    if hasattr(store, "locations"):
        located = store.locations(limit=10000)
    else:  # py-akousma < 0.3: no hoisted lat/lon columns — scan and filter
        located = [
            record
            for record in store.query(limit=10000)
            if isinstance((record.get("location") or {}).get("lat"), (int, float))
            and isinstance((record.get("location") or {}).get("lon"), (int, float))
        ]
    total = store.conn.execute("SELECT COUNT(*) AS n FROM akousmata").fetchone()["n"]
    points = []
    for record in located:
        loc = record.get("location") or {}
        cap = record.get("capture") or {}
        points.append({
            "akousma_id": record["akousma_id"],
            "lat": loc.get("lat"),
            "lon": loc.get("lon"),
            "label": loc.get("label"),
            "accuracy_m": loc.get("accuracy_m"),
            "summary": summary_line(record),
            "created_at": record.get("created_at"),
            "originating_app": (record.get("provenance") or {}).get("originating_app"),
            "tags": list(record.get("tags") or [])[:6],
            "direction": cap.get("direction"),
            "has_audio": bool((record.get("audio") or {}).get("uri")),
        })
    return {"points": points, "located": len(points), "unlocated": total - len(points), "total": total}


def consent_audit(store) -> dict[str, Any]:
    """Every memory's consent and capture conditions at a glance; the export
    gate made visible before it bites."""
    import json as _json

    from akousmata_app.exports import EXPORTABLE_CONSENT

    rows = store.conn.execute("SELECT record FROM akousmata ORDER BY created_at DESC").fetchall()
    items = []
    totals: dict[str, int] = {}
    for row in rows:
        record = _json.loads(row["record"])
        provenance = record.get("provenance") or {}
        consent = str(provenance.get("consent_status") or "unknown")
        totals[consent] = totals.get(consent, 0) + 1
        items.append({
            "akousma_id": record["akousma_id"],
            "summary": summary_line(record)[:90],
            "originating_app": provenance.get("originating_app"),
            "consent_status": consent,
            "rights_note": provenance.get("rights_note"),
            "capture_conditions": provenance.get("capture_conditions"),
            "exportable": consent in EXPORTABLE_CONSENT,
        })
    return {
        "total": len(items),
        "totals": totals,
        "exportable": sum(1 for item in items if item["exportable"]),
        "blocked": sum(1 for item in items if not item["exportable"]),
        "items": items,
    }


def accountability_audit(store) -> dict[str, Any]:
    """Coverage and integrity of accountable listening across the library."""
    import json as _json

    rows = store.conn.execute("SELECT record FROM akousmata ORDER BY created_at DESC").fetchall()
    records = [_json.loads(row["record"]) for row in rows]
    known_ids = {record["akousma_id"] for record in records}
    items = []
    for record in records:
        account = auditum_summary(record, known_record_ids=known_ids)
        items.append({
            "akousma_id": record["akousma_id"],
            "summary": summary_line(record)[:90],
            "originating_app": (record.get("provenance") or {}).get("originating_app"),
            **account,
        })
    receipts = store.forgetting_receipts() if hasattr(store, "forgetting_receipts") else []
    return {
        "total": len(items),
        "accountable": sum(1 for item in items if item["status"] == "accountable"),
        "legacy": sum(1 for item in items if item["status"] == "legacy"),
        "with_issues": sum(1 for item in items if item["status"] == "issues"),
        "ear_swarms": sum(1 for item in items if item["ear_swarm"]),
        "plural_listenings": sum(1 for item in items if item["plural_listening"]),
        "with_disagreement": sum(1 for item in items if item["disagreement_count"] > 0),
        "with_honest_absence": sum(1 for item in items if item["honest_absence_count"] > 0),
        "with_route_decisions": sum(1 for item in items if item["route_decision_count"] > 0),
        "with_stop_decisions": sum(1 for item in items if item["stop_decision_count"] > 0),
        "decision_only": sum(1 for item in items if item["decision_only"]),
        "revisions": sum(1 for item in items if item["revision_of"]),
        "forgetting_receipt_count": len(receipts),
        "forgetting_receipts": receipts,
        "items": items,
    }


CONSENT_VALUES = {"owned", "licensed", "public_domain", "unknown", "restricted"}


def set_consent(store, akousma_id: str, consent_status: str, rights_note: str | None = None) -> dict[str, Any]:
    """A human curator asserting rights over their own library — the one
    provenance field the navigator may write, and it says who set it."""
    if consent_status not in CONSENT_VALUES:
        raise ValueError(f"consent_status must be one of {sorted(CONSENT_VALUES)}")
    record = store.get(akousma_id)
    if record is None:
        raise KeyError(f"akousma not found: {akousma_id}")
    record.setdefault("provenance", {})["consent_status"] = consent_status
    if rights_note is not None:
        if rights_note.strip():
            record["provenance"]["rights_note"] = rights_note.strip()
        else:
            record["provenance"].pop("rights_note", None)
    record.setdefault("extensions", {}).setdefault("akousmata.app", {})["consent_set_by"] = "human"
    store.put(record)
    # A later rights assertion must not silently revive an earlier public grant.
    from akousmata_app.publication import revoke
    revoke(store, akousma_id)
    return record


def stats(store) -> dict[str, Any]:
    rows = store.conn.execute(
        "SELECT originating_app, origin, COUNT(*) AS n FROM akousmata GROUP BY originating_app, origin"
    ).fetchall()
    by_app: dict[str, int] = {}
    by_origin: dict[str, int] = {}
    total = 0
    for row in rows:
        total += row["n"]
        by_app[row["originating_app"] or "unknown"] = by_app.get(row["originating_app"] or "unknown", 0) + row["n"]
        by_origin[row["origin"] or "unknown"] = by_origin.get(row["origin"] or "unknown", 0) + row["n"]
    latest = store.conn.execute("SELECT MAX(created_at) AS m FROM akousmata").fetchone()
    accountability = store.conn.execute(
        """SELECT COUNT(*) AS accountable,
                  SUM(CASE WHEN disagreement_count > 0 THEN 1 ELSE 0 END) AS with_disagreement,
                  SUM(CASE WHEN route_decision_count > 0 THEN 1 ELSE 0 END) AS with_route_decisions,
                  SUM(CASE WHEN stop_decision_count > 0 THEN 1 ELSE 0 END) AS with_stop_decisions
           FROM akousmata WHERE auditum_contract IS NOT NULL"""
    ).fetchone()
    forgetting_receipt_count = len(store.forgetting_receipts()) if hasattr(store, "forgetting_receipts") else 0
    return {
        "total": total,
        "by_app": by_app,
        "by_origin": by_origin,
        "latest_created_at": latest["m"],
        "accountable": accountability["accountable"],
        "with_disagreement": accountability["with_disagreement"] or 0,
        "with_route_decisions": accountability["with_route_decisions"] or 0,
        "with_stop_decisions": accountability["with_stop_decisions"] or 0,
        "forgetting_receipt_count": forgetting_receipt_count,
    }
